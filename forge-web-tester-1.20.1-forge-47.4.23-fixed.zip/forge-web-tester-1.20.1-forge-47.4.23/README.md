# Forge Web Tester — Minecraft 1.20.1 / Forge 47.4.23

Browser-side research/PoC shell for the goal of running **real Minecraft Java Edition 1.20.1 + Forge 47.4.23 + Java 17** in a browser with no local JVM.

## Current status

**Important: this repository is intentionally not a fake Minecraft launcher. The real Forge client is not bundled and the launch path is blocked until the required LWJGL 3 / native integration has been demonstrated.**

What is implemented:

- Static GitHub Pages-compatible site
- Browser capability diagnostics
- Forge MOD `.jar` selection
- Client-side JAR validation (ZIP/JAR magic + size limit)
- SHA-256 calculation in the browser
- Persistent local storage of the selected MOD JAR using IndexedDB
- CheerpJ 4.3 loader integration point
- Canvas setup compatible with the public `cheerpj-natives` LWJGL integration pattern
- Client-side console and error reporting
- GitHub Actions Pages deployment

What is **not** implemented because it is not presently verified:

- Real Minecraft 1.20.1 client boot
- Real Forge 47.4.23 client boot
- Forge ModLauncher/BootstrapLauncher 47.4.23 browser launch
- Loading the stored user JAR into Forge's actual `mods/` runtime
- Real title screen/world rendering
- Real WASD/mouse/keyboard gameplay through the Forge client
- Real Forge logs such as `latest.log`/`crash-report` from a 1.20.1 client
- Microsoft account authentication

## Feasibility findings

### CheerpJ

Leaning Technologies currently documents CheerpJ 4.3 as a WebAssembly JVM supporting Java 8, 11 and 17. The public CheerpJ repository also documents a full OpenJDK-based runtime, virtualized filesystem, dynamic class loading and Java multithreading.

Loader used by this PoC:

`https://cjrtnc.leaningtech.com/4.3/loader.js`

### Minecraft 1.20.1

Minecraft 1.20.1 declares Java 17 compatibility. The version metadata also identifies the official client JAR as a Mojang-hosted object rather than a file we should redistribute in this repository.

A representative 1.20.1 launcher metadata source shows:

- Java major: 17
- asset index: 5
- official client download URL under `piston-data.mojang.com`

### LWJGL

Minecraft 1.20.1 uses **LWJGL 3.3.1**. The client distribution includes multiple LWJGL components, including GLFW, OpenAL, OpenGL, STB, TinyFD and jemalloc, with native artifacts for desktop operating systems.

This matters because browser execution does not load native Windows/Linux `.dll`/`.so` binaries directly. The native boundary must instead be replaced/bridged with browser-compatible Wasm/JS implementations.

### CheerpJ natives

The public `leaningtech/cheerpj-natives` repository explicitly states that it contains **only a partial implementation of LWJGL**. Its documented LWJGL integration expects a browser canvas via `window.lwjglCanvasElement`, and its example configures `java.library.path` to a `cheerpj-natives/natives` directory.

This is sufficient as evidence that a browser-side JNI/native bridge exists, but it is **not evidence that all LWJGL 3.3.1 functions needed by Minecraft 1.20.1 are implemented**.

### Browsercraft

Leaning Technologies' official Browsercraft project currently documents **Minecraft 1.2.5**, not 1.20.1. Its notes say the original Minecraft JAR is fetched from Mojang and used untouched. The public issues currently include an open issue titled “LWJGL 3?”, which is consistent with the fact that the demonstrator is still based on the older Minecraft/LWJGL generation.

The user-provided National-Porting-Association/BrowserForge URL currently returns 404 to the web retrieval layer used for this investigation. GitHub topic indexing still lists that repository as a CheerpJ/Minecraft Forge project with an update date in March 2026, but its source tree could not be retrieved reliably enough for source-level reuse. Therefore **no code from that repository is copied into this PoC**.

## Forge 47.4.23 launch architecture

Forge 47.4.23 is a 1.20.1 release. Current Forge logs show ModLauncher 10.0.9 and a client launch target of `forgeclient` with arguments including:

- `--launchTarget forgeclient`
- `--fml.forgeVersion 47.4.23`
- `--fml.mcVersion 1.20.1`
- `--fml.forgeGroup net.minecraftforge`
- `--fml.mcpVersion 20230612.114412`

A native desktop installation also uses `BootstrapLauncher` with a module-path containing Forge's bootstrap launcher, SecureJarHandler, ASM and related libraries. That architecture is substantially more complex than merely calling `cheerpjRunJar()` on one Forge JAR.

## Class loading

Forge's 1.20.1 client uses a layered launch system involving ModLauncher, BootstrapLauncher and Forge's mod-discovery/class-loading infrastructure. Mod files are discovered from the Forge game directory's `mods` location. The Java-side JAR class loading behavior therefore depends on both the Forge launch layer and the correct game/library path layout.

The PoC stores user JAR bytes locally, but does **not** pretend that an IndexedDB record is already a Forge `mods/` directory. A future working implementation needs a proven CheerpJ virtual-filesystem mapping and a browser-valid Forge launch classpath/module path.

## Authentication

Real Java Edition multiplayer/account flows are not implemented here. A full desktop launcher normally obtains account/session credentials before launching a client. The browser version would need a supported browser-side authentication design and must not ship or proxy user passwords through a custom backend.

For a single-player offline development tester, it may be possible to design a no-account path depending on Forge/Minecraft's client assumptions, but that path has not been verified for 1.20.1.

## OpenGL → WebGL

The historical Browsercraft work demonstrates that OpenGL-to-WebGL compatibility is possible in principle using a browser-side compatibility layer such as gl4es plus Wasm/JS natives. However, the current evidence does not establish complete compatibility for Minecraft 1.20.1 + LWJGL 3.3.1.

Therefore this repository does not provide a Three.js imitation or a Minecraft-like renderer. The canvas remains intentionally blank until a real client can attach to it.

## IndexedDB / OPFS / virtual filesystem

IndexedDB is used by this PoC because it is widely available and can store opaque binary application data. OPFS availability is checked at runtime and shown in the diagnostics panel as a possible future storage backend.

CheerpJ itself provides a virtualized filesystem. The missing piece for this target is not “can a browser store bytes?”; it is “can Forge/Minecraft 1.20.1 see those bytes through the exact virtual path and class/module loading semantics it expects?” That integration is not yet proven.

## SharedArrayBuffer / COOP / COEP / CORS

`SharedArrayBuffer` availability and `crossOriginIsolated` are shown in the diagnostics panel.

Modern browsers restrict shared memory to cross-origin isolated documents. Typical headers are:

- `Cross-Origin-Opener-Policy: same-origin`
- `Cross-Origin-Embedder-Policy: require-corp` (or `credentialless`)

GitHub Pages does not provide arbitrary response-header configuration. That makes cross-origin isolation, if required by a future CheerpJ/Wasm worker design, a deployment issue that must be handled deliberately. A service-worker header shim is **not enabled by default** in this PoC because it can also break third-party cross-origin resources when their CORS/CORP policy is incompatible.

## Resource acquisition and redistribution

This repository intentionally does **not** contain:

- Minecraft client/server JARs
- Minecraft assets
- Forge installer/universal JARs
- Mojang libraries
- LWJGL native desktop binaries
- User MOD JARs

For a production design, download/obtain only files that the user is legally entitled to use. Mojang's EULA states that users may download/install/play the game but generally must not redistribute Mojang-made software/content without permission.

Forge is separately distributed by MinecraftForge and should be obtained from its official distribution channels under its applicable license/terms.

## Security model for uploaded JARs

A MOD JAR is executable Java code. This PoC deliberately does **not** upload JARs to a server, execute them in GitHub Actions, or send them to a backend. The JAR is stored only in browser-local IndexedDB.

Important limitation: once a real JVM executes a MOD JAR, the security boundary becomes the browser JVM/Wasm sandbox. The design must assume hostile Java bytecode and avoid granting dangerous host capabilities beyond what the runtime intentionally exposes.

Recommended future hardening before arbitrary third-party MOD execution:

1. Isolate the runtime origin from the application/control origin.
2. Restrict filesystem access to a dedicated virtual root.
3. Restrict or disable networking unless required.
4. Treat all MOD logs and filenames as untrusted text.
5. Keep the server completely unaware of uploaded JAR contents.
6. Never execute user JARs in CI or build jobs.

## GitHub Pages deployment

1. Create an empty repository.
2. Copy this directory into the repository root.
3. Push the `main` branch.
4. Enable GitHub Pages using **GitHub Actions** as the source.
5. Open the generated Pages URL.

No always-on backend is required by this repository.

## Browser support

The project targets modern desktop browsers with WebAssembly, IndexedDB and WebGL support. Chromium/Edge/Firefox/Safari feature behavior around WebAssembly threading, cross-origin isolation and WebGL can differ. Use the built-in diagnostic panel before drawing conclusions about a specific browser.

## Current known blockers to the requested end state

### Blocker A — LWJGL 3.3.1 native coverage

Public cheerpj-natives coverage is partial. Minecraft 1.20.1 requires more than the historically demonstrated LWJGL path.

### Blocker B — Forge 47.4.23 launch stack

Forge is not a single executable JAR. The browser must reproduce its bootstrap/module/classloader setup and the correct library layout.

### Blocker C — Minecraft 1.20.1 rendering/input

Even after the JVM/class loader problem is solved, the exact LWJGL 3.3.1 GLFW/OpenGL/OpenAL behavior used by Minecraft must map correctly to browser canvas/input/audio APIs.

### Blocker D — Cross-origin resource policy

If the eventual Wasm design needs shared memory, the GitHub Pages origin must be cross-origin isolated. Third-party resources must then be compatible with the chosen COEP/CORP/CORS policy.

### Blocker E — Official data redistribution

Minecraft, its assets and its proprietary libraries must not be copied into this public repository without permission.

## Licensing

The files in this repository are MIT licensed.

CheerpJ is a separate product from Leaning Technologies and is governed by its own licensing terms. The public `cheerpj-natives` repository is Apache-2.0 licensed, but using it does not imply that it provides all functionality needed by Minecraft 1.20.1.

Minecraft Java Edition is a Mojang Studios / Microsoft product. Forge is a separate modding project. This repository is an independent tool and is not endorsed by or affiliated with Mojang Studios, Microsoft, or MinecraftForge.

## Sources used for the feasibility review

- CheerpJ 4.3: https://labs.leaningtech.com/blog/cheerpj-4.3
- CheerpJ repository: https://github.com/leaningtech/cheerpj-meta
- CheerpJ natives: https://github.com/leaningtech/cheerpj-natives
- Browsercraft: https://github.com/leaningtech/browsercraft
- Forge downloads (1.20.1): https://files.minecraftforge.net/net/minecraftforge/forge/index_1.20.1.html
- Forge 1.20.x docs: https://docs.minecraftforge.net/en/1.20.x/
- Mojang version metadata is referenced through the standard official piston-meta/piston-data endpoints.
- Minecraft EULA: https://www.minecraft.net/eula
- MDN SharedArrayBuffer / COOP / COEP: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/SharedArrayBuffer

## Why this repository stops before Phase 1 Minecraft boot

The requested acceptance criterion is unusually strict: **real Minecraft Java 1.20.1 + Forge 47.4.23 + actual 3D client execution**. The current public evidence is not enough to claim that criterion has been met. This repository therefore prefers a reproducible, auditable PoC over a fake success screen or an unverified launcher that appears to work.
