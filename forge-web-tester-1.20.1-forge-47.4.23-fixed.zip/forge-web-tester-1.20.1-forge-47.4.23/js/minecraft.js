export const TARGET = Object.freeze({ minecraft: "1.20.1", forge: "47.4.23", java: "17", lwjgl: "3.3.1" });
export const CHEERPJ_LOADER = "https://cjrtnc.leaningtech.com/4.3/loader.js";

let cheerpjScriptPromise = null;

export function inspectEnvironment() {
  const canvas = document.getElementById("minecraft-canvas");
  const gl2 = canvas?.getContext("webgl2");
  const gl1 = canvas?.getContext("webgl") || canvas?.getContext("experimental-webgl");
  return {
    secureContext: window.isSecureContext,
    indexedDB: "indexedDB" in window,
    opfs: !!navigator.storage?.getDirectory,
    sharedArrayBuffer: typeof SharedArrayBuffer !== "undefined",
    crossOriginIsolated: !!window.crossOriginIsolated,
    webAssembly: typeof WebAssembly !== "undefined",
    webgl2: !!gl2,
    webgl: !!gl1,
    hardwareConcurrency: navigator.hardwareConcurrency || 0,
  };
}

export async function loadCheerpJLoader() {
  if (window.cheerpjInit) return;
  if (cheerpjScriptPromise) return cheerpjScriptPromise;
  cheerpjScriptPromise = new Promise((resolve, reject) => {
    const script = document.createElement("script");
    script.src = CHEERPJ_LOADER;
    script.async = true;
    script.onload = () => resolve();
    script.onerror = () => reject(new Error(`CheerpJ loaderの読み込みに失敗しました: ${CHEERPJ_LOADER}`));
    document.head.appendChild(script);
  });
  return cheerpjScriptPromise;
}

export async function initCheerpJ(canvas, log) {
  await loadCheerpJLoader();
  if (typeof window.cheerpjInit !== "function") throw new Error("cheerpjInit が見つかりません。");
  await window.cheerpjInit();
  if (typeof window.cheerpjCreateDisplay === "function") {
    window.cheerpjCreateDisplay(canvas.width, canvas.height);
  }
  window.lwjglCanvasElement = canvas;
  log?.("INFO", "CheerpJ 4.3 runtime initialized");
  return true;
}

export function explainBlockedLaunch() {
  return [
    "Forge 47.4.23をブラウザ内で本物のクライアントとして起動するための実証済みCheerpJ/LWJGL3ネイティブ経路が、公開資料上確認できません。",
    "Minecraft 1.20.1 は Java 17 と LWJGL 3.3.1 を必要とします。",
    "公開 cheerpj-natives は『partial implementation of LWJGL』で、公式BrowsercraftはMinecraft 1.2.5を対象としています。",
    "したがって現状は起動を偽装せず、診断情報を表示して停止します。",
  ];
}

export async function attemptExperimentalLaunch({ canvas, log }) {
  await initCheerpJ(canvas, log);
  throw new Error(explainBlockedLaunch().join(" "));
}
