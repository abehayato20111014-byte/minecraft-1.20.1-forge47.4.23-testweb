import { attachConsole, log, getLogText, clearLog, installGlobalErrorLogging } from "./console.js";
import { getMod, saveMod, deleteMod } from "./file-manager.js";
import { inspectEnvironment, attemptExperimentalLaunch, TARGET } from "./minecraft.js";

const $ = (id) => document.getElementById(id);
const fileInput = $("mod-file");
const launchButton = $("launch-btn");
const selected = $("selected-file");
const overall = $("overall-status");
const canvasStatus = $("canvas-status");
const placeholder = $("canvas-placeholder");
const matrix = $("matrix");

attachConsole($("console"));
installGlobalErrorLogging();

function formatBytes(bytes) {
  if (!Number.isFinite(bytes)) return "-";
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KiB`;
  return `${(bytes / 1024 / 1024).toFixed(1)} MiB`;
}

function setSelected(record) {
  if (!record) {
    selected.textContent = "選択: なし";
    return;
  }
  selected.textContent = `選択: ${record.name} · ${formatBytes(record.size)} · SHA-256 ${record.sha256}`;
}

// The button is intentionally enabled from page load. A failed capability check
// must be reported after the click, not by making the control impossible to use.
launchButton.disabled = false;

function renderChecks(values) {
  const checks = [
    ["Secure Context", values.secureContext, "HTTPS / secure context"],
    ["IndexedDB", values.indexedDB, "MOD JARの永続保存に利用"],
    ["OPFS", values.opfs, "利用可能なら将来の大容量FS候補"],
    ["WebAssembly", values.webAssembly, "CheerpJ実行基盤"],
    ["SharedArrayBuffer", values.sharedArrayBuffer, "存在しても crossOriginIsolated が別途必要"],
    ["Cross-Origin Isolated", values.crossOriginIsolated, "SAB/Worker系の要件判定"],
    ["WebGL2", values.webgl2, "ブラウザGPU API"],
    ["WebGL", values.webgl, "フォールバックGPU API"],
  ];
  matrix.innerHTML = checks.map(([title, ok, detail]) => `
    <div class="check">
      <div><div class="check-title">${title}</div><div class="check-detail">${detail}</div></div>
      <div class="check-state ${ok ? "ok" : "bad"}">${ok ? "OK" : "NG"}</div>
    </div>
  `).join("");
}

async function refresh() {
  const values = inspectEnvironment();
  renderChecks(values);
  launchButton.disabled = false;

  try {
    const saved = await getMod();
    setSelected(saved);
  } catch (error) {
    setSelected(null);
    log("WARN", "保存JARの読み込みに失敗しました", error.message || String(error));
  }

  log("INFO", `Target ${TARGET.minecraft} / Forge ${TARGET.forge} / Java ${TARGET.java} / LWJGL ${TARGET.lwjgl}`);
  log("INFO", `Environment: WebAssembly=${values.webAssembly}, WebGL2=${values.webgl2}, IndexedDB=${values.indexedDB}, SAB=${values.sharedArrayBuffer}, crossOriginIsolated=${values.crossOriginIsolated}`);
}

fileInput.addEventListener("change", async () => {
  const file = fileInput.files?.[0];
  if (!file) return;
  try {
    const info = await saveMod(file);
    setSelected(info);
    log("INFO", `Stored MOD in browser IndexedDB: ${info.name}`);
    log("INFO", `SHA-256 ${info.sha256}`);
  } catch (error) {
    setSelected(null);
    log("ERROR", "MOD JAR保存に失敗", error.message || String(error));
  }
});

$("clear-btn").addEventListener("click", async () => {
  await deleteMod();
  fileInput.value = "";
  setSelected(null);
  log("INFO", "保存済みMOD JARを削除しました。");
});

$("refresh-checks-btn").addEventListener("click", () => refresh().catch((error) => log("ERROR", "再チェック失敗", error.message)));

$("copy-log-btn").addEventListener("click", async () => {
  await navigator.clipboard.writeText(getLogText());
  log("INFO", "ログをクリップボードへコピーしました。");
});

launchButton.addEventListener("click", async () => {
  launchButton.disabled = true;
  overall.textContent = "PoC試行中";
  canvasStatus.textContent = "CheerpJ初期化";
  try {
    await attemptExperimentalLaunch({ canvas: $("minecraft-canvas"), log });
    placeholder.hidden = true;
    canvasStatus.textContent = "接続済み";
    overall.textContent = "起動済み";
  } catch (error) {
    canvasStatus.textContent = "未起動";
    overall.textContent = "未検証";
    for (const line of String(error.message || error).split("。")) {
      if (line.trim()) log("BLOCKED", line.trim());
    }
    placeholder.hidden = false;
  } finally {
    launchButton.disabled = false;
    try {
      const saved = await getMod();
      setSelected(saved);
    } catch (error) {
      setSelected(null);
      log("WARN", "保存JARの再読込に失敗しました", error.message || String(error));
    }
  }
});

clearLog();
log("INFO", "Forge Web Tester started");
refresh().catch((error) => log("ERROR", "初期化失敗", error.message || String(error)));
