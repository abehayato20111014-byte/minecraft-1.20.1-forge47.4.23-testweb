const state = { lines: [] };
let element = null;

export function attachConsole(target) {
  element = target;
}

export function log(level, message, details = "") {
  const time = new Date().toLocaleTimeString();
  const line = `[${level}] ${time} ${message}${details ? ` ${details}` : ""}`;
  state.lines.push(line);
  if (state.lines.length > 1200) state.lines.shift();
  if (element) {
    element.textContent = state.lines.join("\n");
    element.scrollTop = element.scrollHeight;
  }
  return line;
}

export function getLogText() {
  return state.lines.join("\n");
}

export function clearLog() {
  state.lines.length = 0;
  if (element) element.textContent = "";
}

export function installGlobalErrorLogging() {
  window.addEventListener("error", (event) => {
    log("ERROR", event.message || "window error", event.filename ? `(${event.filename}:${event.lineno})` : "");
  });
  window.addEventListener("unhandledrejection", (event) => {
    log("ERROR", "Unhandled promise rejection", String(event.reason));
  });
}
