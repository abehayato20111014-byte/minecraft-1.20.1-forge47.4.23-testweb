const DB_NAME = "forge-web-tester";
const DB_VERSION = 1;
const STORE = "mods";
const MAX_BYTES = 512 * 1024 * 1024;

function openDb() {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onupgradeneeded = () => {
      if (!request.result.objectStoreNames.contains(STORE)) request.result.createObjectStore(STORE, { keyPath: "id" });
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error || new Error("IndexedDBを開けませんでした"));
  });
}

function txRequest(db, mode, operation) {
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE, mode);
    const store = tx.objectStore(STORE);
    let result;
    try { result = operation(store); } catch (error) { reject(error); return; }
    if (result && "onsuccess" in result) {
      result.onsuccess = () => resolve(result.result);
      result.onerror = () => reject(result.error || new Error("IndexedDB request failed"));
    }
    tx.oncomplete = () => resolve(result?.result ?? result);
    tx.onerror = () => reject(tx.error || new Error("IndexedDB transaction failed"));
  });
}

async function sha256(file) {
  const buffer = await file.arrayBuffer();
  const hash = await crypto.subtle.digest("SHA-256", buffer);
  return [...new Uint8Array(hash)].map((b) => b.toString(16).padStart(2, "0")).join("");
}

async function validateJar(file) {
  if (!file) throw new Error("ファイルが選択されていません。");
  if (!file.name.toLowerCase().endsWith(".jar")) throw new Error(".jar ファイルのみ選択してください。");
  if (file.size > MAX_BYTES) throw new Error(`JARサイズが大きすぎます（上限 ${Math.round(MAX_BYTES / 1024 / 1024)} MiB）。`);
  const head = new Uint8Array(await file.slice(0, 4).arrayBuffer());
  const isZip = head.length === 4 && head[0] === 0x50 && head[1] === 0x4b && (head[2] === 0x03 || head[2] === 0x05 || head[2] === 0x07);
  if (!isZip) throw new Error("JARとして認識できないファイルです（ZIPヘッダがありません）。");
}

export async function saveMod(file) {
  await validateJar(file);
  const db = await openDb();
  const id = "active";
  const record = { id, name: file.name, size: file.size, type: file.type, sha256: await sha256(file), bytes: await file.arrayBuffer(), updatedAt: Date.now() };
  await txRequest(db, "readwrite", (store) => store.put(record));
  db.close();
  return { name: record.name, size: record.size, sha256: record.sha256 };
}

export async function getMod() {
  const db = await openDb();
  const record = await txRequest(db, "readonly", (store) => store.get("active"));
  db.close();
  return record || null;
}

export async function deleteMod() {
  const db = await openDb();
  await txRequest(db, "readwrite", (store) => store.delete("active"));
  db.close();
}

export async function getModBlob() {
  const record = await getMod();
  if (!record) return null;
  return { ...record, blob: new Blob([record.bytes], { type: "application/java-archive" }) };
}
